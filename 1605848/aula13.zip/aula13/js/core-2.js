// temporizadores
// baseiam-se em funcoes e tempo em ms
function escreve() {
  console.log('Escrevendo...');
}

// declarar o meu temporizador
// setTimeout(escreve, 2000); // 2000 => 2s
setInterval(escreve, 500);
