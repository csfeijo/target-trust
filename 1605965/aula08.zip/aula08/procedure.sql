USE EMPRESA;

# STORED PROCEDURE (Procedimento armazenado)

