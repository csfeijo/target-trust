function ola() {
  // é o nosso sub-algoritmo
  // escopo local
  alert('Ola, boa noite!');
}

function saudacao(nome) {
  alert('Boa noite ' + nome);
}
