var idade = 14;

if (idade >= 18) {
  console.log('Pode dirigir');
} else {
  console.log('Não pode dirigir!');
}

// operadores
// aritmeticos
// + - * / %

// logicos
// && -> E  -> AND
// || -> OU -> OR
// !  -> NOT -> NEGADO

//comparadores
// >
// >=
// <
// <=
// == igual
// != diferente
