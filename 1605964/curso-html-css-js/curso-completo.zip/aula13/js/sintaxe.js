// vetor
// caractere => string
var frutas = ['maçã', 'uva', 'laranja', 'pera', 'limao', 'lima', 'kiwi', 'tomate'];

console.log(frutas[0]);
console.log(frutas[1]);
console.log(frutas[2]);
console.log(frutas[3]);
console.log(frutas[4]);
console.log(frutas[5]);

// estruturas de repeticao
var cont = 0;
while (cont < 10) {
  console.log('Contando...', cont);

  cont++;
}

for (var i = 0; i < 10; i++) {
  console.log('Contando com o FOR', i);
}

// automatizando a exibicao do nosso vetor
for (var i = 0; i < frutas.length; i++) {
  console.log(frutas[i]);
}
















