// comentario de uma linha
/* comentario
   multiplas
   linhas */

var nome = 'Cicero';
var idade = 40;
var salario = 2555.36;
var possuiFaculdade = true;
// valor será undefined - pois o JS ainda nao sabe qual a sua "definicao"
var endereco;
// evitem declar multiplas variaveis dessa forma
//var cidade, estado, pais, a, b, c, v;

// alert(endereco);
// o console.log é uma forma do DESENVOLVEDOR DEBUGAR (explorar) o código de forma
// mais discreta
console.log(salario);

var genero = 'M';


